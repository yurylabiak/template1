import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pwd-reset-sent',
  templateUrl: './pwd-reset-sent.component.html',
  styleUrls: ['./pwd-reset-sent.component.scss']
})
export class PwdResetSentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  done() {
    
  }
}
